Layer 2 (.GL2) and Layer 3 (.GL3) are provided as NEGATIVE gerbers, as that's how Altium Designer exports solid planes. Please take it into account.

Board outline defined on .GML

There are Plated and NPTH holes, there's one file for each.

Gerbers exported in RS-274X, Inches, 2:5, Leading Zero suppresion

Drills exported in Inches, 2:5, Leading Zero suppression